/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Cell;
import java.awt.Graphics;
import java.awt.Image;
import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.Timer;
import java.util.TimerTask;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;


/**
 *
 * @author Jeremiah
 */
public class Controller implements Initializable {
    
    @FXML
    private Canvas mycanvas;
    @FXML private Button start;
    @FXML private Button randomgenerator;
    @FXML private Button resetbutton;
    @FXML private ChoiceBox choicebox;
        ObservableList<String> options = FXCollections.observableArrayList("Random","Glider");
    @FXML GraphicsContext gc;
    @FXML TextField heightInput;
    @FXML TextField widthInput;
    @FXML Slider Speedslider;
    @FXML ColorPicker backgroundcolor;
    
    
    boolean play;
    Timer time= new Timer();
    RunGame task= new RunGame();

    Cell gridsize = new Cell(100,100);
    
    @FXML
    public void startfunc(ActionEvent event){
     play=!play;
     if(play) {start.setText("Stop");}else{start.setText("Start");}
    }
    @FXML
    public void resetfunc(ActionEvent e){
            background();
            Cell.resetGrid();            
            Cell.drawCell(gc, mycanvas);
            Cell.creategrid(gc, mycanvas);
    }
    @FXML
    public void speedchange(MouseEvent e){
        int change = 350-30*(int)Math.sqrt(Speedslider.getValue());
        task.cancel();
        task = new RunGame();
        time.scheduleAtFixedRate(task,250, change);
    
    }
    @FXML
    public void choice(MouseEvent e){
        if(choicebox.getValue().equals("Random")){
             Cell.resetGrid();
             Cell.randomcell(gc, mycanvas);
        }
        if(choicebox.getValue().equals("Glider")){
             Cell.resetGrid();
             Cell.drawGlider();
        }
        background();
        Cell.drawCell(gc, mycanvas);
        Cell.creategrid(gc, mycanvas);
    }
    @FXML
    public void randomfunc(ActionEvent e){
             background();
             Cell.randomcell(gc, mycanvas);
             Cell.drawCell(gc, mycanvas);
             Cell.creategrid(gc, mycanvas); 
    }
   
     /*
    @FXML
    public int widthValue(KeyEvent event){
        try{
        double x = Double.parseDouble(widthInput.getText());
        return wid=(int) x;
       }catch(NumberFormatException e){
             return wid=0;
       }
    }
    @FXML
    public int heightValue(KeyEvent event){
      try{
        double y = Double.parseDouble(heightInput.getText());
        return hei=(int) y;
       }catch(NumberFormatException e){
           return hei=0;
       }
    }
   */
   
   
    @FXML
    public void activatecell(MouseEvent event){
        Cell.activatecell((int)event.getY(), (int)event.getX(), gc, mycanvas);
        background();
        Cell.drawCell(gc, mycanvas);
        Cell.creategrid(gc, mycanvas);
    }
    
    private class RunGame extends TimerTask {
        @Override 
        public void run(){
            if(play){
                Cell.rungame();
                gc=mycanvas.getGraphicsContext2D();
                background();
                Cell.drawCell(gc, mycanvas);
                Cell.creategrid(gc, mycanvas);
            }

        }
    }
    @FXML private void changebackgroundcolor(ActionEvent event){
         Color backcolor=backgroundcolor.getValue();
         gc.setFill(backcolor);
         gc.fillRect(0,0,mycanvas.getWidth(),mycanvas.getHeight());
         Cell.creategrid(gc, mycanvas);
    
    
    }
    private void background(){
         gc=mycanvas.getGraphicsContext2D();
         Color backcolor=backgroundcolor.getValue();
         gc.setFill(backcolor);
         gc.fillRect(0,0,mycanvas.getWidth(),mycanvas.getHeight());
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         choicebox.setItems(options); 
         background();
         Cell.creategrid(gc, mycanvas);
         time.scheduleAtFixedRate(task, 500, 500);
    }    

    
}
