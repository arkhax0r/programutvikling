/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Cell;
import Model.CellPattern;
import Model.RulesDescription;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.AnimationTimer;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.input.DragEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;


/**
 *
 * @author Jeremiah
 */
public class Controller implements Initializable {
    
    @FXML private Canvas mycanvas;
    @FXML private Button start;
    @FXML private Button randomgenerator;
    @FXML private Button resetbutton;
    @FXML private Button gameshape; 
    @FXML private ChoiceBox choicebox;
        ObservableList<String> options = FXCollections.observableArrayList("Select Pattern","Exploder","Glider","Tumbler","10 Cell Row");
    @FXML GraphicsContext gc;
    @FXML TextField heightInput;
    @FXML TextField widthInput;
    @FXML Slider Speedslider;
    @FXML Slider Gridslider;
    @FXML ColorPicker backgroundcolor;
    @FXML ColorPicker cellcolor;


    private boolean shape;
    private boolean play=false;
    private double time=15;
    private double startspeed=1;
    private int griddimension=50;
    

    AnimationTimer timer = new AnimationTimer(){
        @Override
        public void handle(long now) {
            if(play){
                time -=1;
                if(time<=startspeed){
                Cell.rungame(griddimension,griddimension);
                background();
                Cell.drawCell(griddimension,griddimension,gc, mycanvas, cellcolor,shape);
                Cell.creategrid(griddimension,griddimension,gc, mycanvas,shape);
                time=15;
                }
            }
        }
                  
    };
    
    @FXML
    public void changeshape(ActionEvent event){
    shape=!shape;
            if(shape){gameshape.setText("Circle");}else{gameshape.setText("Square");}
            background();
            Cell.drawCell(griddimension,griddimension,gc, mycanvas, cellcolor,shape);
            Cell.creategrid(griddimension,griddimension,gc, mycanvas,shape);
    }
    
    @FXML
    public void startfunc(ActionEvent event){
     play=!play;
     if(play) {start.setText("Stop");}else{start.setText("Start");}
    }
    @FXML
    public void resetfunc(ActionEvent e){
            background();
            Cell.resetGrid(griddimension,griddimension);            
            Cell.drawCell(griddimension,griddimension,gc, mycanvas, cellcolor,shape);
            Cell.creategrid(griddimension,griddimension,gc, mycanvas,shape);
    }
   @FXML
    public void speedchange(MouseEvent e){
        startspeed=Speedslider.getValue();
    }  

   @FXML
   public void gridchange(MouseEvent e){
       griddimension=(int) Gridslider.getValue();
       background();
       Cell.drawCell(griddimension,griddimension,gc, mycanvas, cellcolor,shape);
       Cell.creategrid(griddimension,griddimension,gc, mycanvas,shape);
   }
    
    
    //choivebox listener
    
    public void choiceboxfunction(){
         choicebox.setValue("Select Pattern");
         choicebox.setItems(options); 
          choicebox.getSelectionModel().selectedItemProperty().addListener((v, oldValue,newValue)-> {
          
        if(choicebox.getValue().equals("Exploder")){
             Cell.resetGrid(griddimension,griddimension);
             CellPattern.drawExploder();
        }
        if(choicebox.getValue().equals("Glider")){
             Cell.resetGrid(griddimension,griddimension);
             CellPattern.drawGlider();
        }
        if(choicebox.getValue().equals("Tumbler")){
             Cell.resetGrid(griddimension,griddimension);
             CellPattern.drawTumbler();

        }
        if(choicebox.getValue().equals("10 Cell Row")){
             Cell.resetGrid(griddimension,griddimension);
             CellPattern.draw10cellrow();
        }
        background();
        Cell.drawCell(griddimension,griddimension,gc, mycanvas, cellcolor,shape);
        Cell.creategrid(griddimension,griddimension,gc, mycanvas,shape);
     });
    }
    
    @FXML
    public void randomfunc(ActionEvent e){
             background();
             Cell.randomcell(griddimension,griddimension,gc, mycanvas);
             Cell.drawCell(griddimension,griddimension,gc, mycanvas, cellcolor,shape);
             Cell.creategrid(griddimension,griddimension,gc, mycanvas,shape); 
    }
    @FXML
    public void clickactivatecell(MouseEvent event){
        Cell.clickactivatecell((int)event.getY(), (int)event.getX(), gc, mycanvas,griddimension,griddimension);
        background();
        Cell.drawCell(griddimension,griddimension,gc, mycanvas, cellcolor,shape);
        Cell.creategrid(griddimension,griddimension,gc, mycanvas,shape);
    }
    @FXML
    public void dragactivatecell(MouseEvent event){
        Cell.dragactivatecell((int)event.getY(), (int)event.getX(), gc, mycanvas,griddimension,griddimension);
        background();
        Cell.drawCell(griddimension,griddimension,gc, mycanvas, cellcolor,shape);
        Cell.creategrid(griddimension,griddimension,gc, mycanvas,shape);
    }

    @FXML protected void changecellcolor(ActionEvent event){
        Color cellc = cellcolor.getValue();
        gc.setFill(cellc);
        Cell.drawCell(griddimension,griddimension,gc, mycanvas, cellcolor,shape);
        Cell.creategrid(griddimension,griddimension,gc, mycanvas,shape);
    
    }
    @FXML private void changebackgroundcolor(ActionEvent event){
         Color backcolor=backgroundcolor.getValue();
         gc.setFill(backcolor);
         gc.fillRect(0,0,mycanvas.getWidth(),mycanvas.getHeight());
         Cell.drawCell(griddimension,griddimension,gc, mycanvas, cellcolor,shape);
         Cell.creategrid(griddimension,griddimension,gc, mycanvas,shape);
    
    }
    private void background(){
         gc=mycanvas.getGraphicsContext2D();
         Color backcolor=backgroundcolor.getValue();
         gc.setFill(backcolor);
         gc.fillRect(0,0,mycanvas.getWidth(),mycanvas.getHeight());
    }
    
    public void Rulesfunction(ActionEvent event){
        RulesDescription.display("Rules", "Rules:\n"+
                                          "1. Any live cell with fewer than two live neighbours dies, as if caused by underpopulation.\n" +
                                          "2.Any live cell with two or three live neighbours lives on to the next generation.\n" +
                                          "3.Any live cell with more than three live neighbours dies, as if by overpopulation.\n" +
                                          "4.Any dead cell with exactly three live neighbours becomes a live cell, as if by reproduction.");
    }
    
    public void CloseWindow(ActionEvent event){
      Platform.exit();
      System.exit(0);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         choiceboxfunction();
         backgroundcolor.setValue(Color.GRAY);
         cellcolor.setValue(Color.GREEN);
         background();
         Cell.drawCell(griddimension,griddimension,gc, mycanvas, cellcolor,shape);
         Cell.creategrid(griddimension,griddimension,gc, mycanvas,shape);
         timer.start();
    }    

    
}
