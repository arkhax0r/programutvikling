/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import static Model.Cell.currentmove;
import static Model.Cell.heig;
import static Model.Cell.widt;

/**
 *
 * @author Jeremiah
 */
public class Rules {
    
    
       public static boolean decideneighbor(int i, int j){
       int neighbor=0;
       //sjekker nabo på venstre siden
       if(j>0){                                                  
           if(currentmove[i][j-1]){neighbor++;}                 //rettved
           if(i>0){if(currentmove[i-1][j-1]){neighbor++;}}      //over
           if(i<heig-1){if(currentmove[i+1][j-1]){neighbor++;}} //under
       }
       //sjekker nabo på høyre siden
       if(j<widt-1){                                                  
           if(currentmove[i][j+1]){neighbor++;}                 //rettved
           if(i>0){if(currentmove[i-1][j+1]){neighbor++;}}      //over
           if(i<heig-1){if(currentmove[i+1][j+1]){neighbor++;}} //under
       }
       if(i>0){if(currentmove[i-1][j]){neighbor++;}}            //rettover
       if(i<heig-1){if(currentmove[i+1][j]){neighbor++;}}       //rettunder
       
       
       if(neighbor==3)return true;
       if(currentmove[i][j] && neighbor==2)return true;
       else {return false;}
      }
    
}
