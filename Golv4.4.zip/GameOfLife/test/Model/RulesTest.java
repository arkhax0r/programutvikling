/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Controller.Controller;
import static Model.Cell.nextmove;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Jeremiah
 */
public class RulesTest {
    
    
      byte [][] testmove ={{0,0,0}
                          ,{0,1,0}
                          ,{0,0,0}};
      
      byte [][] testmove2 ={{0,0,0}
                           ,{1,1,1}
                           ,{0,0,0}};
      
      byte [][] testmove3 ={{0,0,1}
                           ,{1,1,0}
                           ,{0,0,0}};      
        
    
    public RulesTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of decideneighbor method, of class Rules.
     */
    @Test
    public void testDecideneighbor() {
        System.out.println("decideneighbor");
       
        
        int i = 1;
        int j = 1;
        
        Cell.loadnewmove(testmove, 0, 0, 0);
            
        byte expResult =0;
        byte result = Rules.decideneighbor(i, j);
        assertEquals(expResult, result);

    }
     /**
     * Test of decideneighbor method, of class Rules.
     */
    @Test
    public void testDecideneighbor2() {
        System.out.println("decideneighbor");
       
        
        int i = 1;
        int j = 1;
        
        Cell.loadnewmove(testmove2, 0, 0, 0);
            
        byte expResult =1;
        byte result = Rules.decideneighbor(i, j);
        assertEquals(expResult, result);

    }
         /**
     * Test of decideneighbor method, of class Rules.
     */
    @Test
    public void testDecideneighbor3() {
        System.out.println("decideneighbor");
       
        
        int i = 1;
        int j = 1;
        
        Cell.loadnewmove(testmove3, 0, 0, 0);
            
        byte expResult =1;
        byte result = Rules.decideneighbor(i, j);
        assertEquals(expResult, result);

    }
    

    
    
    
}
