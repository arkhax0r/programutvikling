/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import static Model.Cell.currentmove;
import java.util.Arrays;
  
/**
 *
 * @author Jeremiah
 */
public class CellPattern {
       

   public static void drawGlider(){
   currentmove[24][24]=1;
   currentmove[25][25]=1;
   currentmove[26][25]=1;
   currentmove[26][24]=1;
   currentmove[26][23]=1;
 
   }
   public static void drawExploder(){
   currentmove[24][24]=1;
   currentmove[24][25]=1;
   currentmove[24][26]=1;
   currentmove[25][24]=1;
   currentmove[25][26]=1;
   currentmove[26][24]=1;
   currentmove[26][25]=1;
   currentmove[26][26]=1;
   
   }
   public static void drawTumbler(){
   currentmove[24][24]=1;            currentmove[24][26]=1;
   currentmove[24][23]=1;            currentmove[24][27]=1;
   currentmove[23][23]=1;            currentmove[23][26]=1;
   currentmove[23][24]=1;            currentmove[23][27]=1; 
   currentmove[25][24]=1;            currentmove[25][26]=1; 
   currentmove[26][24]=1;            currentmove[26][26]=1; 
   currentmove[26][22]=1;            currentmove[26][28]=1;
   currentmove[27][24]=1;            currentmove[27][26]=1;
   currentmove[27][22]=1;            currentmove[27][28]=1;
   currentmove[28][23]=1;            currentmove[28][27]=1;
   currentmove[28][22]=1;            currentmove[28][28]=1;
   
   }
   public static void draw10cellrow(){
   currentmove[25][25]=1;
   currentmove[25][24]=1; 
   currentmove[25][23]=1; 
   currentmove[25][22]=1; 
   currentmove[25][21]=1; 
   currentmove[25][20]=1; 
   currentmove[25][26]=1; 
   currentmove[25][27]=1; 
   currentmove[25][28]=1; 
   currentmove[25][29]=1; 
   
   
   }
}
