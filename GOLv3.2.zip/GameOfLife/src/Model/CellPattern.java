/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import static Model.Cell.currentmove;

/**
 *
 * @author Jeremiah
 */
public class CellPattern {
       
   public static void drawGlider(){
   currentmove[24][24]=true;
   currentmove[25][25]=true;
   currentmove[26][25]=true;
   currentmove[26][24]=true;
   currentmove[26][23]=true;
   }
   public static void drawExploder(){
   currentmove[24][24]=true;
   currentmove[24][25]=true;
   currentmove[24][26]=true;
   currentmove[25][24]=true;
   currentmove[25][26]=true;
   currentmove[26][24]=true;
   currentmove[26][25]=true;
   currentmove[26][26]=true;
   
   }
   public static void drawTumbler(){
   currentmove[24][24]=true;            currentmove[24][26]=true;
   currentmove[24][23]=true;            currentmove[24][27]=true;
   currentmove[23][23]=true;            currentmove[23][26]=true;
   currentmove[23][24]=true;            currentmove[23][27]=true; 
   currentmove[25][24]=true;            currentmove[25][26]=true; 
   currentmove[26][24]=true;            currentmove[26][26]=true; 
   currentmove[26][22]=true;            currentmove[26][28]=true;
   currentmove[27][24]=true;            currentmove[27][26]=true;
   currentmove[27][22]=true;            currentmove[27][28]=true;
   currentmove[28][23]=true;            currentmove[28][27]=true;
   currentmove[28][22]=true;            currentmove[28][28]=true;
   }
   public static void draw10cellrow(){
   currentmove[25][25]=true;
   currentmove[25][24]=true; 
   currentmove[25][23]=true; 
   currentmove[25][22]=true; 
   currentmove[25][21]=true; 
   currentmove[25][20]=true; 
   currentmove[25][26]=true; 
   currentmove[25][27]=true; 
   currentmove[25][28]=true; 
   currentmove[25][29]=true; 
   
   
   }
}
