/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;



import java.util.Random;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.ColorPicker;
import javafx.scene.paint.Color;

/**
 *
 * @author Jeremiah
 */
public class Cell {
    
    
        
    static int wid=500; 
    static int hei=500;
    static byte currentmove[][]=new byte[hei][wid];
    static byte nextmove[][]=new byte[hei][wid];

    
    public static void creategrid(int heig,int widt, GraphicsContext g,Canvas c,boolean shape){
            
    g= c.getGraphicsContext2D();
    g.strokeRect(0,0,c.getWidth(),c.getHeight());
    g.setFill(Color.BLACK);  
    
    
    if(shape==false){
    //Horizontal linje
    for(int i =1; i<heig;i++){
            int y = (int) (i * c.getHeight()/heig);
           g.strokeLine(0,y,c.getWidth(),y);
            
        }
    //vertikal linje
        for(int j=1; j<widt;j++){
         int x = (int) (j * c.getWidth()/widt);
           g.strokeLine(x,0,x,c.getHeight());
        
        }
    }else{
       for(int y=0;y<heig;y++){
            for(int x=0;x<widt;x++){
                
                       int n =(int) (y*c.getHeight()/heig);
                       int m=(int) (x*c.getWidth()/widt);
                       
                       g.strokeOval(m, n, c.getWidth()/widt, c.getHeight()/heig);
                
            }
        }
    }
    }
  
    public static void randomcell(int heig,int widt,GraphicsContext g, Canvas c){
        g=c.getGraphicsContext2D();
        Random r = new Random();
           for(int y=0;y<heig;y++){
            for (int x=0;x<widt;x++){
                int z = r.nextInt(2);
                currentmove[y][x]=(byte) z;
            }
        
        }
    }
    
    public static void drawCell(int heig,int widt,GraphicsContext g, Canvas c,ColorPicker cp,boolean shape){
        
        for(int y=0;y<heig;y++){
            for(int x=0;x<widt;x++){
                if(currentmove [y][x]==1){
                       Color cellc = cp.getValue();
                       g.setFill(cellc);
                       
                       int n =(int) (y*c.getHeight()/heig);
                       int m=(int) (x*c.getWidth()/widt);
                       
                       if(shape==false){
                           g.fillRect(m, n, c.getWidth()/widt, c.getHeight()/heig);
                       }else{
                           g.fillOval(m, n, c.getWidth()/widt, c.getHeight()/heig);}
                }
            }
        }
    
    }
    
   public static void resetGrid(int heig,int widt){
        for(int y=0;y<heig;y++){
            for(int x=0;x< widt;x++){
                if(currentmove[y][x]==1){
                    currentmove[y][x]=0;
                }
            }
        }
    }

   
   
   public static void clickactivatecell(int y, int x, GraphicsContext g,Canvas c,int heig,int widt){
        int i=(int) (heig*y/c.getHeight());
        int j=(int) (widt*x/c.getWidth());
           
        if(currentmove[i][j]==0){currentmove[i][j]=1;} else {
            currentmove[i][j]=0;
        }

    }
    public static void dragactivatecell(int y, int x, GraphicsContext g,Canvas c,int heig,int widt){
        int i=(int) (heig*y/c.getHeight());
        int j=(int) (widt*x/c.getWidth());
                
        if(currentmove[i][j]==1){currentmove[i][j]=0;}
        if(currentmove[i][j]==0){currentmove[i][j]=1;}
        
    }
   public static void rungame(int heig,int widt){
       for(int i=0;i<heig;i++){
        for(int j=0;j<widt;j++){
                nextmove[i][j]=Rules.decideneighbor(i,j);
            }
        }
       for(int i=0;i<heig;i++){
        for(int j=0;j<widt;j++){
                currentmove[i][j]=nextmove[i][j];
            }
        }

    }
    public static void loadnewmove(byte[][] newmove,int j){
        
        for (int y = 0; y < newmove.length; y++){
            for (int x = 0 ; x < newmove[y].length; x++){
                currentmove[y+(j/2)][x+(j/2)] = newmove[y][x];
            }
        }
    }
   
      
}
