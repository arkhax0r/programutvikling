
Utf�rte oppgaver 

Oppgave 1 planlegging
Oppgave 2 datastruktur
Oppgave 3 animasjon
Oppgave 4 testing
Oppgave 5 filbehandling
Oppgave 6 dynamisk

