/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 *
 * @author Jeremiah
 */
public class Importrle {

    
    public static String filechooser(){
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Import Pattern");
        File file = chooser.showOpenDialog(new Stage());
        String text="";
        
       
        if(file!=null){
               
               
         try (
               FileReader read = new FileReader(file);
               BufferedReader reader= new BufferedReader(read);){
                              
               String line =reader.readLine();
                while(line !=null){
                   text+=" "+line;
                   line=reader.readLine();
               }
                
               System.out.println(text);
               
        }catch(Exception e){
                System.err.println("Invalid file, please choose a rle file.");
                }
        }
        return text;
    }
    
    public static byte[][] decoder(String text){

        Pattern size = Pattern.compile( "x = (\\d+), y = (\\d+)");
        Matcher matchSize = size.matcher(text);        
        int x=0, y=0;   
        if (matchSize.find()){
             x = Integer.parseInt(matchSize.group(1));
             y = Integer.parseInt(matchSize.group(2));
             

        }
       byte[][] board = new byte[y][x];

 

        

        Pattern FindStringForCells = Pattern.compile("( ?\\d? ?b? ?\\d? ?o? ?)+[$!]");
        Pattern FindAllCells = Pattern.compile("\\d*b|\\d*o");
        
        Matcher matchFindStringForCells = FindStringForCells.matcher(text);
        
        int row = 0, length, column;
        while (matchFindStringForCells.find()) {   // finner alle rader
            matchFindStringForCells.group().replaceAll("\\s ",".");

            //System.out.print(matchFindStringForCells.group());
            Matcher matchFindAllCells = FindAllCells.matcher(matchFindStringForCells.group());

            column = 0;
            while (matchFindAllCells.find()) {
                //System.out.println(matchFindAllCells.group());
                //System.out.print(" | cell: " + matchFindAllCells.group() + " column: " + column);
                if (matchFindAllCells.group().length() != 1) {
                    length = Integer.parseInt(matchFindAllCells.group().substring(0, matchFindAllCells.group().length() - 1));
                    //System.out.println(length);
                   
                    if (matchFindAllCells.group().charAt(matchFindAllCells.group().length() - 1) == 'b') {
                        for (int column_index = column; column_index < column + length; column_index++) {
                            board[row][column_index] = 0;
                            //System.out.println(board[row][column_index] + " ");
                        }
                    } else {
                        for (int column_index = column; column_index < column + length; column_index++) {
                            board[row][column_index] = 1;
                            //System.out.println(board[row][column_index] + " ");
                        }
                    }
                     column += length;
                } else {
                    if (matchFindAllCells.group().charAt(0) == 'b') {
                        board[row][column] = 0;
                       //System.out.println(board[row][column] + " ");
                    } else {
                        board[row][column] = 1;
                        //System.out.println(board[row][column] + " ");
                    }

                    column++;
                }
                //System.out.println();
            }// end of 2.while

         row++;
        }//end of 1. while
        return board;

    }
    
        
}
