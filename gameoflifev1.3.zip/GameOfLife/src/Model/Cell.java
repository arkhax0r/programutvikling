/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.awt.Graphics;
import java.awt.Image;
import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

/**
 *
 * @author Jeremiah
 */
public class Cell {
    
    static int widt=50; 
    static int heig=50;
    static boolean currentmove[][]=new boolean[heig][widt];
    static boolean nextmove[][]=new boolean[heig][widt];
    
    public Cell(int y, int x){
        this.widt=x;
        this.heig=y;
    }
    
    public static void creategrid(GraphicsContext g,Canvas c){
            
    g= c.getGraphicsContext2D();
    g.strokeRect(0,0,c.getWidth(),c.getHeight());
    g.setFill(Color.BLACK);    
    //Horizontal linje
    for(int i =1; i<heig;i++){
            int y = (int) (i * c.getHeight()/heig);
           g.strokeLine(0,y,c.getWidth(),y);
            
        }
    //vertikal linje
        for(int j=1; j<widt;j++){
         int x = (int) (j * c.getWidth()/widt);
           g.strokeLine(x,0,x,c.getHeight());
        
        }
    }
  
    public static void randomcell(GraphicsContext g, Canvas c){
        g=c.getGraphicsContext2D();
        Random r = new Random();
           for(int y=0;y<heig;y++){
            for (int x=0;x<widt;x++){
                boolean z = r.nextBoolean();
                currentmove[y][x]=z;
            }
        
        }
    }
    
    public static void drawCell(GraphicsContext g, Canvas c){
        for(int y=0;y<heig;y++){
            for(int x=0;x<widt;x++){
                if(currentmove [y][x]==true){
                       g.setFill(Color.GREEN);
                       
                       int n =(int) (y*c.getHeight()/heig);
                       int m=(int) (x*c.getWidth()/widt);
                       
                       g.fillRect(m, n, c.getWidth()/widt, c.getHeight()/heig);
                }else{
                    g.setFill(Color.GRAY);
                       
                       int n =(int) (y*c.getHeight()/heig);
                       int m=(int) (x*c.getWidth()/widt);
                       
                       g.fillRect(m, n, c.getWidth()/widt, c.getHeight()/heig);
                }
            }
        }
    
    }
    
   public static void resetGrid(){
        for(int y=0;y<heig;y++){
            for(int x=0;x< widt;x++){
                if(currentmove[y][x]==true){
                    currentmove[y][x]=false;
                }
            }
        }
    }
   
   public static void drawGlider(){
   currentmove[24][24]=true;
   currentmove[25][25]=true;
   currentmove[26][25]=true;
   currentmove[26][24]=true;
   currentmove[26][23]=true;
   }
   
   
   public static void activatecell(int y, int x, GraphicsContext g,Canvas c){
        int i=(int) (heig*y/c.getHeight());
        int j=(int) (widt*x/c.getWidth());
        currentmove[i][j]=!currentmove[i][j];
        
    }
   public static void rungame(){
       for(int i=0;i<heig;i++){
        for(int j=0;j<widt;j++){
                nextmove[i][j]=decideneighbor(i,j);
            }
        }
       for(int i=0;i<heig;i++){
        for(int j=0;j<widt;j++){
                currentmove[i][j]=nextmove[i][j];
            }
        }

    }
   public static boolean decideneighbor(int i, int j){
       int neighbor=0;
       //sjekker nabo på venstre siden
       if(j>0){                                                  
           if(currentmove[i][j-1]){neighbor++;}                 //rettved
           if(i>0){if(currentmove[i-1][j-1]){neighbor++;}}      //over
           if(i<heig-1){if(currentmove[i+1][j-1]){neighbor++;}} //under
       }
       //sjekker nabo på høyre siden
       if(j<widt-1){                                                  
           if(currentmove[i][j+1]){neighbor++;}                 //rettved
           if(i>0){if(currentmove[i-1][j+1]){neighbor++;}}      //over
           if(i<heig-1){if(currentmove[i+1][j+1]){neighbor++;}} //under
       }
       if(i>0){if(currentmove[i-1][j]){neighbor++;}}            //rettover
       if(i<heig-1){if(currentmove[i+1][j]){neighbor++;}}       //rettunder
       
       
       if(neighbor==3)return true;
       if(currentmove[i][j] && neighbor==2)return true;
       else {return false;}
      }   
      
}
