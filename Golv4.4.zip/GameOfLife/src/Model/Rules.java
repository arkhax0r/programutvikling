/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import static Model.Cell.currentmove;
import static Model.Cell.hei;
import static Model.Cell.wid;

/**
 *
 * @author Jeremiah
 */
public class Rules {
    
       /**
        * Method for counting the neighbors of an active cell and deciding if a cell will die of live.
        * 
        * 
        * @param i coordinates of the y axis of a cell
        * @param j coordinates of the x axis of a cell
        * @return returns a byte array that contains new coordinates for all the cells that are alive and dead.
        */
       public static byte decideneighbor(int i, int j){
       int griddimension=50;
       int neighbor=0;
       //sjekker nabo på venstre siden
       if(j>0){                                                  
           if(currentmove[i][j-1]==1){neighbor++;}                 //rettved
           if(i>0){if(currentmove[i-1][j-1]==1){neighbor++;}}      //over
           if(i<hei-1){if(currentmove[i+1][j-1]==1){neighbor++;}} //under
       }
       //sjekker nabo på høyre siden
       if(j<wid-1){                                                  
           if(currentmove[i][j+1]==1){neighbor++;}                 //rettved
           if(i>0){if(currentmove[i-1][j+1]==1){neighbor++;}}      //over
           if(i<hei-1){if(currentmove[i+1][j+1]==1){neighbor++;}} //under
       }
       if(i>0){if(currentmove[i-1][j]==1){neighbor++;}}            //rettunder
       if(i<hei-1){if(currentmove[i+1][j]==1){neighbor++;}}       //rettover
       
       
       if(neighbor==3)return 1;
       if(currentmove[i][j]==1 && neighbor==2)return 1;
       else {return 0;}
      }
    
}
