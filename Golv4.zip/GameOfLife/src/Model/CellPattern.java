/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Arrays;

  
/**
 *
 * @author Jeremiah
 */
public class CellPattern {
     
  

   public static byte[][] drawGlider(){
      
    byte[][] newmove = {{0,1,0},
                        {0,0,1},
                        {1,1,1}};
    return newmove;
   }
   
   public static byte[][] drawExploder(){

    byte[][] newmove = {{1,0,1,0,1},
                        {1,0,0,0,1},
                        {1,0,0,0,1},
                        {1,0,0,0,1},
                        {1,0,1,0,1}};
    return newmove;
   }
   
   public static byte[][] drawTumbler(){
     
    byte[][] newmove = {{0,1,1,0,1,1,0},
                        {0,1,1,0,1,1,0},
                        {0,0,1,0,1,0,0},
                        {1,0,1,0,1,0,1},
                        {1,0,1,0,1,0,1},
                        {1,1,0,0,0,1,1}};
    return newmove;
   }
   
   public static byte[][] draw10cellrow(){
    
    byte[][] newmove = {{1,1,1,1,1,1,1,1,1,1}};
    return newmove;
   }
}
